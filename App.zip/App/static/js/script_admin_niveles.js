let eliminar = (id) => {
    fetch('/admin/eliminar-nivel/'+id)
    .then(response => response.json())
    .then(data => {
        console.log(data);
        fila = document.getElementById('linea_'+id);
        fila.style.border = "3px solid red";
        setTimeout(function() {
            fila.remove();
        }, 400);
    })
    .catch(error => {
        console.log('error:', error);
    });
}

let actualizar = (id) => {
    tr = document.getElementById('linea_'+id);
    nombre = document.getElementById('nombre_'+id).value;
    fetch('/admin/actualizar-nivel',{
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
            'id': id,
            'nombre': nombre
        })
    })
    .then(response => response.json())
    .then(data => {
        console.log(data);
        tr.style.border = "3px solid blue";
        setTimeout(function() {
            tr.style.border = "";
        }, 400);
    })
    .catch(error => {
        console.log('error:', error);
    })
}

let nuevo = () => {
    const tabla = document.getElementById('body');
    let tr = document.createElement('tr');
    let td = document.createElement('td');
    let input = document.createElement('input');
    input.readOnly = true;
    ultimo = ultimo + 1;
    input.id = "id_"+(ultimo);
    input.value = ultimo;
    td.appendChild(input);
    tr.appendChild(td);
    td = document.createElement('td');
    input = document.createElement('input');
    input.id = "nombre_"+(ultimo);
    td.appendChild(input);
    tr.appendChild(td);
    td = document.createElement('td');
    let button = document.createElement('button');
    button.className = "green";
    button.innerHTML = "Crear";
    let i = ultimo;
    button.addEventListener('click', function() {
        agregar(i);
    });
    td.appendChild(button);
    tr.appendChild(td);
    tr.id="linea_"+ultimo;
    tabla.appendChild(tr);
}

let agregar = (id) => {
    nombre = document.getElementById('nombre_'+id).value;
    fetch('/admin/agregar-nivel',{
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
            'id': id,
            'nombre': nombre
        })
    })
    .then(response => response.json())
    .then(data => {
        console.log(data);
        tr = document.getElementById('linea_'+id);
        let button = tr.querySelector('button.green');
        let td = button.closest('td');
        td.remove();
        button = document.createElement('button');
        button.className = "blue";
        button.innerHTML = "Actualizar";
        button.addEventListener('click', function() {
            actualizar(id);
        });
        td = document.createElement('td');
        td.appendChild(button);
        tr.appendChild(td);
        button = document.createElement('button');
        button.className = "red";
        button.innerHTML = "Eliminar";
        button.addEventListener('click', function(){
            eliminar(id);
        });
        td = document.createElement('td');
        td.appendChild(button);
        tr.appendChild(td);
    });
}