const ctx = document.getElementById('turnosChart').getContext('2d');
let chart;

function updateChart(data) {
    const labels = data.map(item => item[0]);
    const counts = data.map(item => item[1]);
    document.getElementById('total').innerHTML = data[0][1]+data[1][1];
    if (chart) {
        chart.destroy();
    }

    chart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Cantidad de Turnos',
                data: counts,
                backgroundColor: 'rgba(54, 162, 235, 0.2)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

function fetchData() {
    const municipioId = document.getElementById('municipioSelect').value;
    const nivelId = document.getElementById('nivelSelect').value;

    fetch(`/filter/${municipioId}/${nivelId}`)
        .then(response => response.json())
        .then(data => {
            updateChart(data);
        });
}

document.getElementById('filterBtn').addEventListener('click', fetchData);

fetchData();