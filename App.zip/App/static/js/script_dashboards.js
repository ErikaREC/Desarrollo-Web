
const municipios = turnosPorMunicipio.map(item => item[0]);
const turnosMunicipio = turnosPorMunicipio.map(item => item[1]);

const estados = turnosPorEstado.map(item => item[0]);
const turnosEstado = turnosPorEstado.map(item => item[1]);

const niveles = turnosPorNivel.map(item => item[0]);
const turnosNivel = turnosPorNivel.map(item => item[1]);

const asuntos = turnosPorAsunto.map(item => item[0]);
const turnosAsunto = turnosPorAsunto.map(item => item[1]);

new Chart(document.getElementById('turnosPorMunicipioChart'), {
    type: 'bar',
    data: {
        labels: municipios,
        datasets: [{
            label: 'Turnos por Municipio',
            data: turnosMunicipio,
            backgroundColor: 'rgba(54, 162, 235, 0.2)',
            borderColor: 'rgba(54, 162, 235, 1)',
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});

new Chart(document.getElementById('turnosPorEstadoChart'), {
    type: 'pie',
    data: {
        labels: estados,
        datasets: [{
            label: 'Turnos por Estado',
            data: turnosEstado,
            backgroundColor: ['rgba(75, 192, 192, 0.2)', 'rgba(255, 99, 132, 0.2)'],
            borderColor: ['rgba(75, 192, 192, 1)', 'rgba(255, 99, 132, 1)'],
            borderWidth: 1
        }]
    }
});

new Chart(document.getElementById('turnosPorNivelChart'), {
    type: 'bar',
    data: {
        labels: niveles,
        datasets: [{
            label: 'Turnos por Nivel',
            data: turnosNivel,
            backgroundColor: 'rgba(153, 102, 255, 0.2)',
            borderColor: 'rgba(153, 102, 255, 1)',
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});

new Chart(document.getElementById('turnosPorAsuntoChart'), {
    type: 'bar',
    data: {
        labels: asuntos,
        datasets: [{
            label: 'Turnos por Asunto',
            data: turnosAsunto,
            backgroundColor: 'rgba(255, 159, 64, 0.2)',
            borderColor: 'rgba(255, 159, 64, 1)',
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});