from sqlalchemy import create_engine, Column, Integer, String, PrimaryKeyConstraint, ForeignKey, or_
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import declarative_base, relationship, sessionmaker
import hashlib

engine = create_engine('sqlite:///base_de_datos.db', echo=False)

Base = declarative_base()

class Admin(Base):
    __tablename__ = 'admin'
    usuario = Column(String, primary_key=True)
    nombre = Column(String, nullable=False)
    contraseña = Column(String, nullable=False)

    def create(self):
        self.contraseña =  hashlib.sha256(self.contraseña.encode()).hexdigest()
        session.add(self)
        session.commit()

    def read(usuario, contraseña):
        return session.query(Admin).filter(Admin.usuario == usuario, Admin.contraseña ==  hashlib.sha256(contraseña.encode()).hexdigest()).first()
    
    def delete(self):
        session.delete(self)
        session.commit()

class Nivel(Base):
    __tablename__ = 'nivel'
    id = Column(Integer, primary_key=True, autoincrement=True)
    nombre = Column(String, nullable=False)

    turnos = relationship('Turno', back_populates='nivel')

    def create(self):
        session.add(self)
        session.commit()
    
    def read(id):
        return session.query(Nivel).filter(Nivel.id == id).first()

    def list_all():
        return session.query(Nivel).all()
    
    def delete(self):
        session.delete(self)
        session.commit()

class Municipio(Base):
    __tablename__ = 'municipio'
    id = Column(Integer, primary_key=True, autoincrement=True)
    nombre = Column(String, nullable=False)

    turnos = relationship('Turno', back_populates='municipio')

    def create(self):
        session.add(self)
        session.commit()
    
    def read(id):
        return session.query(Municipio).filter(Municipio.id == id).first()

    def list_all():
        return session.query(Municipio).all()
    
    def delete(self):
        session.delete(self)
        session.commit()

class Asunto(Base):
    __tablename__ = 'asunto'
    id = Column(Integer, primary_key=True, autoincrement=True)
    nombre = Column(String, nullable=False)

    turnos = relationship('Turno', back_populates='asunto')

    def create(self):
        session.add(self)
        session.commit()
    
    def read(id):
        return session.query(Asunto).filter(Asunto.id == id).first()

    def list_all():
        return session.query(Asunto).all()
    
    def delete(self):
        session.delete(self)
        session.commit()

class Alumno(Base):
    __tablename__ = 'alumno'
    curp = Column(String, primary_key=True)
    nombre = Column(String, nullable=False)
    paterno = Column(String, nullable=False)
    materno = Column(String, nullable=False)

    turnos = relationship('Turno', back_populates='alumno')
    def create(self):
        session.add(self)
        session.commit()
    
    def read(curp):
        return session.query(Alumno).filter(Alumno.curp == curp).first()

    def update(self, nombre = None, paterno = None, materno = None):
        if nombre is not None:
            self.nombre = nombre
        if paterno is not None:
            self.paterno = paterno
        if materno is not None:
            self.materno = materno
        session.commit()

    def delete(self):
        session.delete(self)
        session.commit()

class Turno(Base):
    __tablename__ = 'turno'
    numero_turno = Column(Integer, primary_key=True)
    municipio_id = Column(Integer, ForeignKey('municipio.id'), primary_key=True)
    nombre = Column(String, nullable=False)
    telefono = Column(String, nullable=False)
    celular = Column(String, nullable=False)
    correo = Column(String, nullable=False)
    estado = Column(String, nullable=False)
    asunto_id = Column(Integer, ForeignKey('asunto.id'))
    nivel_id = Column(Integer, ForeignKey('nivel.id'))
    alumno_curp = Column(String, ForeignKey('alumno.curp'))

    asunto = relationship('Asunto', back_populates='turnos')
    nivel = relationship('Nivel', back_populates='turnos')
    alumno = relationship('Alumno', back_populates='turnos')
    municipio = relationship('Municipio', back_populates='turnos')

    __table_args__ = (
        PrimaryKeyConstraint('municipio_id', 'numero_turno'),
    )

    def create(self):
        ultimo_id = session.query(Turno.numero_turno).filter(Turno.municipio_id == self.municipio_id).order_by(Turno.numero_turno.desc()).first()
        if ultimo_id:
            self.numero_turno = int(ultimo_id[0]) + 1
        else:
            self.numero_turno = 1
        session.add(self)
        session.commit()
    
    def read(numero_turno, municipio_id):
        return session.query(Turno).filter(Turno.numero_turno == numero_turno, Turno.municipio_id == municipio_id).first()

    def read_curp(curp):
        return session.query(Turno).filter(Turno.estado == 'pendiente', Turno.alumno_curp == curp).first()
    
    def read_curp_numero(curp, numero_turno):
        print('\n\n\n\n\n\n\n', curp, numero_turno)
        return session.query(Turno).filter(Turno.alumno_curp == curp, Turno.numero_turno == numero_turno).first()

    def listar():
        return session.query(Turno).all()

    def listar_pendientes():
        return session.query(Turno).filter(Turno.estado == 'pendiente').all()
    
    def listar_curp(curp):
        return session.query(Turno).filter(Turno.alumno_curp == curp).all()
    
    def listar_nombre(nombre):
        return session.query(Turno).filter(Turno.nombre.ilike(f'%{nombre}%'),).all()

    def update(self, nombre = None, telefono = None, celular = None, correo = None, estado = None, asunto_id = None, nivel_id = None, alumno_curp = None):
        if nombre is not None:
            self.nombre = nombre
        if telefono is not None:
            self.telefono = telefono
        if celular is not None:
            self.celular = celular
        if correo is not None:
            self.correo = correo
        if estado is not None:
            self.estado = estado
        if asunto_id is not None:
            self.asunto_id = asunto_id
        if nivel_id is not None:
            self.nivel_id = nivel_id
        if alumno_curp is not None:
            self.alumno_curp = alumno_curp
        session.commit()

    def delete(self):
        session.delete(self)
        session.commit()

Base.metadata.create_all(engine)
Session = sessionmaker(bind=engine)
session = Session()