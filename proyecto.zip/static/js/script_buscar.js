let validar = () => {
    var numero_turno = document.getElementById('numero_turno').value.trim();
    var curp = document.getElementById('curp').value.trim();
    var valido = true

    document.getElementById('error-numero_turno').innerText = '';
    document.getElementById('error-curp').innerText = '';
    
    if (numero_turno === "") {
        document.getElementById('error-numero_turno').innerText = 'Por favor, ingresa el numero de turno.';
        valido = false;
    }

    if (curp === "") {
        document.getElementById('error-curp').innerText = 'Por favor, ingresa la curp del alumno.';
        valido = false;
    }
    else if (curp.length !== 18){
        document.getElementById('error-curp').innerText = 'El CURP debe tener exactamente 18 caracteres.';
        valido = false;
    }
    
    if (valido){
        fetch('/buscar-turno',{
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                'numero_turno': numero_turno,
                'curp': curp
            })
        })
        .then(response => response.json())
        .then(data =>{
            if ('error' in data){
                alert('no se encontró un turno con el alumno y el numero de turno');
            }
            else{
                form = document.getElementById('actualizar-turno');
                form.style.display = "block";
                document.getElementById('numero').value=data.numero_turno;
                document.getElementById('curp2').value=data.curp2_turno;
                document.getElementById('nombre_completo').value=data.nombre;
                document.getElementById('telefono').value=data.telefono;
                document.getElementById('celular').value=data.celular;
                document.getElementById('correo').value=data.correo;
                document.getElementById('nivel').querySelector(`option[value="${data.nivel_id}"]`).selected = true;
                document.getElementById('asunto').querySelector(`option[value="${data.asunto_id}"]`).selected = true;
            }
        })
    }
    return false;
}

let validarActualizacion = () => {
    var errores = document.getElementsByClassName('error');
    for (var i = 0; i < errores.length; i++) {
        errores[i].innerText = '';
    }

    var nombre_completo = document.getElementById('nombre_completo').value.trim();
    var nombre = document.getElementById('nombre').value.trim();
    var paterno = document.getElementById('paterno').value.trim();
    var materno = document.getElementById('materno').value.trim();
    var telefono = document.getElementById('telefono').value.trim();
    var celular = document.getElementById('celular').value.trim();
    var correo = document.getElementById('correo').value.trim();
    var nivel = document.getElementById('nivel').value;
    var municipio = document.getElementById('municipio').value;
    var asunto = document.getElementById('asunto').value;

    var valido = true;

    if (nombre_completo === "") {
        document.getElementById('error-nombre_completo').innerText = 'Por favor, ingresa el nombre completo.';
        valido = false;
    }

    if (nombre === "") {
        document.getElementById('error-nombre').innerText = 'Por favor, ingresa el nombre.';
        valido = false;
    }

    if (paterno === "") {
        document.getElementById('error-paterno').innerText = 'Por favor, ingresa el apellido paterno.';
        valido = false;
    }

    if (materno === "") {
        document.getElementById('error-materno').innerText = 'Por favor, ingresa el apellido materno.';
        valido = false;
    }

    if (telefono === "") {
        document.getElementById('error-telefono').innerText = 'Por favor, ingresa el teléfono.';
        valido = false;
    } else if (!(/^\d{10}$/.test(telefono))) {
        document.getElementById('error-telefono').innerText = 'El teléfono debe tener exactamente 10 dígitos.';
        valido = false;
    }

    if (celular === "") {
        document.getElementById('error-celular').innerText = 'Por favor, ingresa el celular.';
        valido = false;
    } else if (!(/^\d{10}$/.test(celular))) {
        document.getElementById('error-celular').innerText = 'El celular debe tener exactamente 10 dígitos.';
        valido = false;
    }

    if (correo === "") {
        document.getElementById('error-correo').innerText = 'Por favor, ingresa el correo.';
        valido = false;
    } else if (!(/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.]+\.[a-zA-Z]{2,}$/.test(correo))) {
        document.getElementById('error-correo').innerText = 'El correo no tiene un formato válido.';
        valido = false;
    }

    if (nivel === "0") {
        document.getElementById('error-nivel').innerText = 'Por favor, selecciona un nivel.';
        valido = false;
    }

    if (municipio === "0") {
        document.getElementById('error-municipio').innerText = 'Por favor, selecciona un municipio.';
        valido = false;
    }

    if (asunto === "0") {
        document.getElementById('error-asunto').innerText = 'Por favor, selecciona un asunto.';
        valido = false;
    }

    return valido;
}