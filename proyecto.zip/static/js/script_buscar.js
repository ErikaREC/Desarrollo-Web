let validar = () => {
    var numero_turno = document.getElementById('numero_turno').value.trim();
    var curp = document.getElementById('curp').value.trim();
    var valido = true

    document.getElementById('error-numero_turno').innerText = '';
    document.getElementById('error-curp').innerText = '';
    
    if (numero_turno === "") {
        document.getElementById('error-numero_turno').innerText = 'Por favor, ingresa el numero de turno.';
        valido = false;
    }

    if (curp === "") {
        document.getElementById('error-curp').innerText = 'Por favor, ingresa la curp del alumno.';
        valido = false;
    }
    else if (curp.length !== 18){
        document.getElementById('error-curp').innerText = 'El CURP debe tener exactamente 18 caracteres.';
        valido = false;
    }
    
    if (valido){
        fetch('/buscar-turno',{
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                'numero_turno': numero_turno,
                'curp': curp
            })
        })
        .then(response => response.json())
        .then(data =>{
            if ('error' in data){
                alert('no se encontró un turno con el alumno y el numero de turno');
            }
            else{
                form = document.getElementById('actualizar-turno');
                form.style.display = "block";
                document.getElementById('numero').value=data.numero_turno;
                document.getElementById('curp2').value=data.curp2_turno;
                document.getElementById('nombre_completo').value=data.nombre;
                document.getElementById('telefono').value=data.telefono;
                document.getElementById('celular').value=data.celular;
                document.getElementById('correo').value=data.correo;
                document.getElementById('municipio').value=data.municipio_id;
                document.getElementById('nivel').value=data.nivel_id;
                document.getElementById('asunto').value=data.asunto_id;
            }
        })
    }
    return false;
}