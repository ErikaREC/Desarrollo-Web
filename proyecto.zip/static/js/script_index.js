let validar = () => {

    var errores = document.getElementsByClassName('error');
    for (var i = 0; i < errores.length; i++) {
        errores[i].innerText = '';
    }

    var nombre_completo = document.getElementById('nombre_completo').value.trim();
    var curp = document.getElementById('curp').value.trim();
    var nombre = document.getElementById('nombre').value.trim();
    var paterno = document.getElementById('paterno').value.trim();
    var materno = document.getElementById('materno').value.trim();
    var telefono = document.getElementById('telefono').value.trim();
    var celular = document.getElementById('celular').value.trim();
    var correo = document.getElementById('correo').value.trim();
    var nivel = document.getElementById('nivel').value;
    var municipio = document.getElementById('municipio').value;
    var asunto = document.getElementById('asunto').value;

    var valido = true;

    if (nombre_completo === "") {
        document.getElementById('error-nombre_completo').innerText = 'Por favor, ingresa el nombre completo.';
        valido = false;
    }

    if (curp === "") {
        document.getElementById('error-curp').innerText = 'Por favor, ingresa el CURP.';
        valido = false;
    } else if (curp.length !== 18) {
        document.getElementById('error-curp').innerText = 'El CURP debe tener exactamente 18 caracteres.';
        valido = false;
    }

    if (nombre === "") {
        document.getElementById('error-nombre').innerText = 'Por favor, ingresa el nombre.';
        valido = false;
    }

    if (paterno === "") {
        document.getElementById('error-paterno').innerText = 'Por favor, ingresa el apellido paterno.';
        valido = false;
    }

    if (materno === "") {
        document.getElementById('error-materno').innerText = 'Por favor, ingresa el apellido materno.';
        valido = false;
    }

    if (telefono === "") {
        document.getElementById('error-telefono').innerText = 'Por favor, ingresa el teléfono.';
        valido = false;
    } else if (!(/^\d{10}$/.test(telefono))) {
        document.getElementById('error-telefono').innerText = 'El teléfono debe tener exactamente 10 dígitos.';
        valido = false;
    }

    if (celular === "") {
        document.getElementById('error-celular').innerText = 'Por favor, ingresa el celular.';
        valido = false;
    } else if (!(/^\d{10}$/.test(celular))) {
        document.getElementById('error-celular').innerText = 'El celular debe tener exactamente 10 dígitos.';
        valido = false;
    }

    if (correo === "") {
        document.getElementById('error-correo').innerText = 'Por favor, ingresa el correo.';
        valido = false;
    } else if (!(/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.]+\.[a-zA-Z]{2,}$/.test(correo))) {
        document.getElementById('error-correo').innerText = 'El correo no tiene un formato válido.';
        valido = false;
    }

    if (nivel === "0") {
        document.getElementById('error-nivel').innerText = 'Por favor, selecciona un nivel.';
        valido = false;
    }

    if (municipio === "0") {
        document.getElementById('error-municipio').innerText = 'Por favor, selecciona un municipio.';
        valido = false;
    }

    if (asunto === "0") {
        document.getElementById('error-asunto').innerText = 'Por favor, selecciona un asunto.';
        valido = false;
    }

    return valido;
}

let limpiar = () => {
    document.getElementById('nombre_completo').value = "";
    document.getElementById('curp').value = "";
    document.getElementById('nombre').value = "";
    document.getElementById('paterno').value = "";
    document.getElementById('materno').value = "";
    document.getElementById('telefono').value = "";
    document.getElementById('celular').value = "";
    document.getElementById('correo').value = "";
    document.getElementById('nivel').value = "";
    document.getElementById('municipio').value = "";
    document.getElementById('asunto').value = "";
}