let validar = () => {
    var usuario = document.getElementById('usuario').value.trim();
    var contraseña = document.getElementById('contraseña').value.trim();
    var valido = true

    document.getElementById('error-usuario').innerText = '';
    document.getElementById('error-contraseña').innerText = '';
    
    if (usuario === "") {
        document.getElementById('error-usuario').innerText = 'Por favor, ingresa tu usuario.';
        valido = false;
    }

    if (contraseña === "") {
        document.getElementById('error-contraseña').innerText = 'Por favor, ingresa tu contraseña.';
        valido = false;
    }
    
    return valido;
}